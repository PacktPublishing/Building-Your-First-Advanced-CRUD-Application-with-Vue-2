<template>
  <div id="app">
    Hello World!
  </div>
</template>

<script>
export default {
  name: 'music-db',
};
</script>
