module.exports = {
  NODE_ENV: '"production"',
  API_LOCATION: '""',
  BROADCAST_AUTH_ENDPOINT: '""',
  PUSHER_KEY: '""',
  PUSHER_CLUSTER: '""',
}
