<template>
  <v-layout>
    <v-grid variant="container">
      <v-row>
        <v-col>
          <v-card v-if="artist">
            <v-card-heading>
              <v-card-title>{{ artist.fullName }} #{{ artistId }}</v-card-title>
            </v-card-heading>
            <v-card-body>
              <v-definition>
                <v-definition-term>Gender</v-definition-term>
                <v-definition-description>{{ artist.gender }}</v-definition-description>
                <v-definition-term>Birthday</v-definition-term>
                <v-definition-description>{{ artist.birthday }}</v-definition-description>
                <v-definition-term>Biography</v-definition-term>
                <v-definition-description>{{ artist.biography }}</v-definition-description>
              </v-definition>
            </v-card-body>
            <v-card-footer>
              <v-button
                variant="minimal"
                @click.native="redirectToEditPage()"
              >Edit
              </v-button>
              <v-button
                :variants="['minimal', 'minimal--danger']"
                @click.native="destroyArtist()"
              >Delete
              </v-button>
            </v-card-footer>
          </v-card>
        </v-col>
      </v-row>
    </v-grid>
  </v-layout>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'artists-show',

    /**
     * The properties that can be used.
     */
    props: {
      /**
       * The given artist identifier.
       */
      artistId: {
        type: [String, Number],
        required: true,
      },
    },

    /**
     * The data the page can use.
     *
     * @returns {Object} The data.
     */
    data() {
      return {
        artist: {
          fullName: 'John Doe',
          firstName: 'John',
          lastName: 'Doe',
          gender: 'Male',
          birthday: '01-01-2000',
          biography: 'lorem ipsum',
        },
      };
    },

    /**
     * The methods which the page can use.
     */
    methods: {
      /**
       * Method used to fetch an artist.
       *
       * @param {Number} id The id of the artist.
       */
      fetchArtist(id) {
        console.log(id);
      },

      /**
       * Method used to redirect the user to the artist edit page.
       */
      redirectToEditPage() {
        this.$router.push({
          name: 'artists.edit',
          props: {
            artistId: this.artistId,
          },
        });
      },

      /**
       * Method used to destroy an artist.
       * It'll dispatch the destroy action on the artist module.
       */
      destroyArtist() {
        // Todo
      },
    },

    /**
     * The components that are being used.
     */
    components: {
      VLayout: require('@/layouts/base'),
    },

    watch: {
      artistId(id) {
        this.fetchArtist(id);
      },
    },

    mounted() {
      this.fetchArtist(this.artistId);
    },
  };
</script>
