<template>
  <div>
    {{ pageName }}
  </div>
</template>
<script>
  export default {
    data() {
      return {
        pageName: 'song.edit',
      };
    },
  };
</script>
