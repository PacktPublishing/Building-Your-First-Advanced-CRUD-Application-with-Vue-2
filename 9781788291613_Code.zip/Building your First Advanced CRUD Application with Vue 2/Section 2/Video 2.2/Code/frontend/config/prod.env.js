module.exports = {
  NODE_ENV: '"production"',
  API_LOCATION: '"http://api.music-db.dev"',
  BROADCAST_ENDPOINT: '"http://api.music-db.dev/broadcasting/auth"',
  PUSHER_KEY: '"615dd7082856f0699fd0"',
  PUSHER_CLUSTER: '"eu"',
}
