<template>
  <div>
    {{ pageName }}
  </div>
</template>
<script>
  export default {
    data() {
      return {
        pageName: 'albums.index',
      };
    },
  };
</script>
