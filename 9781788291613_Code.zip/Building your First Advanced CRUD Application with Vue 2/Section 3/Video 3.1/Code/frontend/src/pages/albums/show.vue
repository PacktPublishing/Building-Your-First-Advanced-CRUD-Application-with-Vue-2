<template>
  <v-layout>
    <v-grid variant="container">
      <v-row>
        <v-col>
          <v-card v-if="album">
            <v-card-heading>
              <v-card-title>{{ album.title}}</v-card-title>
            </v-card-heading>
            <v-card-body>
              <v-definition>
                <v-definition-term>Release Date</v-definition-term>
                <v-definition-description>{{ album.releaseDate }}</v-definition-description>
              </v-definition>
            </v-card-body>
            <v-card-footer>
              <v-button
                variant="minimal"
                @click.native="redirectToEditPage()"
              >Edit
              </v-button>
              <v-button
                :variants="['minimal', 'minimal--danger']"
                @click.native="destroyAlbum()"
              >Delete
              </v-button>
            </v-card-footer>
          </v-card>
        </v-col>
      </v-row>
    </v-grid>
  </v-layout>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'albums-show',

    /**
     * The properties that can be used.
     */
    props: {
      /**
       * The given artist identifier.
       */
      albumId: {
        type: [String, Number],
        required: true,
      },
    },

    /**
     * The data the page can use.
     *
     * @returns {Object} The data.
     */
    data() {
      return {
        album: {
          title: 'Hello World!',
          releaseDate: '01-01-2000',
        },
      };
    },

    /**
     * The methods which the page can use.
     */
    methods: {
      /**
       * Method used to fetch an artist.
       *
       * @param {Number} id The id of the artist.
       */
      fetchAlbum(id) {
        console.log(id);
      },

      /**
       * Method used to redirect the user to the artist edit page.
       */
      redirectToEditPage() {
        this.$router.push({
          name: 'albums.edit',
          props: {
            albumId: this.albumId,
          },
        });
      },

      /**
       * Method used to destroy an artist.
       * It'll dispatch the destroy action on the artist module.
       */
      destroyAlbum() {
        // Todo
      },
    },

    /**
     * The components that are being used.
     */
    components: {
      VLayout: require('@/layouts/base'),
    },

    watch: {
      albumId(id) {
        this.fetchAlbum(id);
      },
    },

    mounted() {
      this.fetchAlbum(this.albumId);
    },
  };
</script>
