<template>
  <v-layout>
    <v-grid variant="container">
      <v-row>
        <v-col>
          <v-card v-if="song">
            <v-card-heading>
              <v-card-title>Update song {{ song.title }}</v-card-title>
            </v-card-heading>
            <v-card-body>
              <v-form @submit.prevent.native="updateSong">
                <v-form-group>
                  <v-text-field
                    placeholder="Title"
                    variant="block"
                    v-model="song.title"
                  />
                </v-form-group>
                <v-form-group>
                  <v-auto-complete
                    v-model="album.selected"
                    :items="album.items"
                    @change="fetchAlbums"
                    placeholder="Search albums..."
                  />
                </v-form-group>
              </v-form>
            </v-card-body>
            <v-card-footer>
              <v-button
                variant="minimal"
                @click.native="updateSong"
              >Save
              </v-button>
              <v-button
                :variants="['minimal', 'minimal--danger']"
                @click.native="goBack"
              >Cancel
              </v-button>
            </v-card-footer>
          </v-card>
        </v-col>
      </v-row>
    </v-grid>
  </v-layout>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'songs-edit',

    /**
     * The properties that can be used.
     */
    props: {
      /**
       * The given artist identifier.
       */
      songId: {
        type: [String, Number],
        required: true,
      },
    },

    /**
     * The data the page can use.
     *
     * @returns {Object} The data.
     */
    data() {
      return {
        album: {
          items: [],
          selected: {
            id: 1,
            content: 'John Doe',
          },
        },
        song: {
          title: 'Hello World!',
        },
      };
    },

    /**
     * The methods which the page can use.
     */
    methods: {
      /**
       * Method used to fetch a song.
       *
       * @param {Number} id The id of the song.
       */
      fetchSong(id) {
        console.log(id);
      },

      /**
       * Method used to return to the previous page.
       */
      goBack() {
        this.$router.push({
          name: 'songs.show',
          props: {
            albumId: this.albumId,
          },
        });
      },

      /**
       * Method used to update a song.
       * It'll dispatch the update action on the song module.
       */
      updateSong() {
        // Todo
      },

      fetchAlbums() {
        // todo
      },

      fetchAlbum(songId) {
        console.log(songId);
      },
    },

    watch: {
      songId(id) {
        this.fetchSong(id);
      },
    },

    mounted() {
      this.fetchSong(this.songId);
    },

    /**
     * The components that are being used.
     */
    components: {
      VLayout: require('@/layouts/base'),
    },
  };
</script>
