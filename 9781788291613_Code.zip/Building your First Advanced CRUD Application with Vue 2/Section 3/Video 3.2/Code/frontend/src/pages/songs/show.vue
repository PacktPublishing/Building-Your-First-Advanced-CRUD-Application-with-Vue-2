<template>
  <v-layout>
    <v-grid variant="container">
      <v-row>
        <v-col>
          <v-card v-if="song">
            <v-card-heading>
              <v-card-title>{{ song.title }}</v-card-title>
            </v-card-heading>
            <v-card-body>
              <v-definition>
                <v-definition-term>Title</v-definition-term>
                <v-definition-description>{{ song.title }}</v-definition-description>
              </v-definition>
            </v-card-body>
            <v-card-footer>
              <v-button
                variant="minimal"
                @click.native="redirectToEditPage()"
              >Edit
              </v-button>
              <v-button
                :variants="['minimal', 'minimal--danger']"
                @click.native="destroySong()"
              >Delete
              </v-button>
            </v-card-footer>
          </v-card>
        </v-col>
      </v-row>
    </v-grid>
  </v-layout>
</template>
<script>
  export default {
    /**
     * The name of the page.
     */
    name: 'songs-show',

    /**
     * The properties that can be used.
     */
    props: {
      /**
       * The given artist identifier.
       */
      songId: {
        type: [String, Number],
        required: true,
      },
    },

    /**
     * The data the page can use.
     *
     * @returns {Object} The data.
     */
    data() {
      return {
        song: {
          title: 'lorem ipsum',
        },
      };
    },

    /**
     * The methods which the page can use.
     */
    methods: {
      /**
       * Method used to fetch an artist.
       *
       * @param {Number} id The id of the artist.
       */
      fetchSong(id) {
        console.log(id);
      },

      /**
       * Method used to redirect the user to the artist edit page.
       */
      redirectToEditPage() {
        this.$router.push({
          name: 'songs.edit',
          props: {
            songId: this.songId,
          },
        });
      },

      /**
       * Method used to destroy an artist.
       * It'll dispatch the destroy action on the artist module.
       */
      destroySong() {
        // Todo
      },
    },

    /**
     * The components that are being used.
     */
    components: {
      VLayout: require('@/layouts/base'),
    },

    watch: {
      songId(id) {
        this.fetchSong(id);
      },
    },

    mounted() {
      this.fetchSong(this.songId);
    },
  };
</script>
