<template>
  <div>
    <v-grid variant="container">
      <v-row>
        <v-col :variants="['md-6', 'md-offset-3']">
          <!-- The content will be placed here -->
          <slot></slot>
        </v-col>
      </v-row>
    </v-grid>
  </div>
</template>
<script>
  export default {
    /**
     * The name of the layout.
     */
    name: 'minimal-layout',
  };
</script>
