module.exports = {
  NODE_ENV: '"production"',
  API_LOCATION: '""',
  API_CLIENT_ID: '""',
  API_CLIENT_SECRET: '""',
  BROADCAST_AUTH_ENDPOINT: '""',
  PUSHER_KEY: '""',
  PUSHER_CLUSTER: '""',
}
